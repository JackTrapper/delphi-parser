UNIT Good;
{Test unit for Cocolsoft Delphi grammar.}
(* ------|---------|---------|---------|---------|---------|---------|------- *)
(* Copyright (C) 1999 Cocolsoft Computer Solutions. All Rights Reserved.      *)
(* ------|---------|---------|---------|---------|---------|---------|------- *)
// This unit should have no errors or warnings when run against
//   the Cocolsoft Delphi grammar.
// This unit has examples of different language constructs. For example, there
//   has already been three different forms of comment!

INTERFACE

IMPLEMENTATION

Uses
  Forms,    {for TForm}
  StdCtrls, {for TLabel, TMemo}
  Windows;  {for DWORD}

Type
  TForm1 = class(TForm)
    Label1: TLabel;
    Memo1:  TMemo;
  end;

  TYourForm = class(TForm);

  iSet      = 0..225;
  iSubSet   = SET of iSet;

  TForm2 = class(TForm)
    Label1: TLabel;
    Memo1:  TMemo;
    FMemoColour: TMemo;
    property MemoColourR: TMemo read FMemoColour;
  end;

VAR
  Character     : CHAR;
  IntegerNumber : INTEGER;
  CaptionStr    : STRING;

  iSet1         : iSubSet;

  MyString      : STRING;

  X             : Integer;

CONST
  MyArray: ARRAY[0..2] of DWORD = (
    $FFFFFDA0, $00000227, $00000228);

  CWNear: Word = $133F;

  MyBoolean1 = TRUE;

PROCEDURE DoStuffA;
BEGIN
  {do nothing}
END;

PROCEDURE DoStuffB;
  LABEL 9999;
BEGIN
  {do nothing}
9999 :
END;

procedure DoStuffC;
{The simplest assembly routine.}
asm
end;

function BitOn(const val: longint; const TheBit: byte): LongInt;
begin
  result := val and not (1 shl TheBit);
end;

BEGIN
  Character     := 'A';
  IntegerNumber := 2;

  {CASE statement with a default ELSE clause}
  CASE Character OF
    'A' : DoStuffA;
    'B' : DoStuffA;
    'C' : DoStuffA;
    'D' : DoStuffA;
    ELSE DoStuffB;  {default}
  END;

  {CASE statement where the statement following the case list is a 
  designator}
  CASE Character OF
    'A' : CaptionStr := 'Cocolsoft';
    'B' : CaptionStr := 'Computer' ;
    'C' : CaptionStr := 'Solutions'; 
  END;

  iSet1 := [1, 2, 3..X MOD 12, 100];

  MyString := 'This is line 1'#13#10'This is line 2';


(* ------|---------|---------|---------|---------|---------|---------|------- *)
END.